u = np.random.uniform(size=4)
print(u)

# [0.95339335 0.00394827 0.51219226 0.81262096]