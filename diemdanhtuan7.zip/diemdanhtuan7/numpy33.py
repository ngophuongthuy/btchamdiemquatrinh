p = np.random.permutation(10)
print(p)

# [0 7 5 2 3 9 6 4 8 1]