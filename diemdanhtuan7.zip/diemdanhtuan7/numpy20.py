np.random.randint(0, 2) # Ngẫu nhiên số nguyên trong khoảng [0, 2)

 # 0