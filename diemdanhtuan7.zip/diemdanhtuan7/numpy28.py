a = np.random.rand()
b = np.random.rand(4)  # Mảng có 1x8 phần tử
c = np.random.rand(2, 3)  # Mảng có 2x3 phần tử

print("a = ", a)
print("b = ", b)
print("c = ", c)

# a =  0.3421628209488957
# b =  [0.46813023 0.08351749 0.45755406 0.39447444]
# c =  [[0.07105495 0.33631271 0.88374921]
#  [0.96496987 0.62399799 0.88844741]]