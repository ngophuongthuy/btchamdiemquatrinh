import pandas as pd
s = pd.Series([0,1,2,3], index=["a","b","c","d"])
print(s)